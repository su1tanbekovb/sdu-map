// Paste your Supabase keys here (see README.md, step 3).
// Leave both empty to run in DEMO mode (data is saved only in this browser).
window.SDU_CONFIG = {
  supabaseUrl: "",   // example: "https://abcdxyz.supabase.co"
  supabaseKey: ""    // the "anon public" key (it is safe to publish)
};
